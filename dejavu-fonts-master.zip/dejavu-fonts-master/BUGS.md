See http://dejavu-fonts.github.io/Bugs.html

<!-- $Id$ -->
